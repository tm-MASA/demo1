#!/usr/bin/env pwsh
Write-Host "Building Docker image 'tm-masa:latest'..."
if (-not (Get-Command docker -ErrorAction SilentlyContinue)) {
  Write-Error "Docker not found in PATH. Install Docker Desktop and retry."
  exit 1
}
docker build -t tm-masa:latest .
if ($LASTEXITCODE -ne 0) { Write-Error "docker build failed"; exit $LASTEXITCODE }
Write-Host "Running container on http://127.0.0.1:8080... (Ctrl+C to stop)"
docker run --rm -p 8080:8080 tm-masa:latest
