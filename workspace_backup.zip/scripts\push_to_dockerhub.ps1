param(
  [string]$user
)
if (-not $user) {
  $user = Read-Host 'Docker Hub username (e.g. tuusuario)'
}
if (-not (Get-Command docker -ErrorAction SilentlyContinue)) { Write-Error "Docker not found"; exit 1 }
Write-Host "Tagging image as $user/tm-masa:latest"
docker tag tm-masa:latest $user/tm-masa:latest
Write-Host "Logging in to Docker Hub (interactive)"
docker login
Write-Host "Pushing image..."
docker push $user/tm-masa:latest
